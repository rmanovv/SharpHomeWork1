﻿using System;

//Create, compile and run a “Hello C#” console application.
//Ensure you have named the application well (e.g. “”HelloCSharp”).

class HelloCSharp
{
    static void Main()
    {
        Console.WriteLine("Hello C#");
    }
}

