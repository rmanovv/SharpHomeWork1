﻿using System;
//Create console application that prints your first and last name, each at a separate line.
    class FirstAndLastName
    {
        static void Main()
        {
            Console.WriteLine("Radoslav\nManov");
        }
    }

