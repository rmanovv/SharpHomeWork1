﻿using System;
//ite a program to print the numbers 1, 101 and 1001, each at a separate line.
//Name the program correctly.

class PrintNumbers
{
    static void Main()
    {
        Console.WriteLine("1\n101\n1001");
    }
}

